import { useEffect, useState } from "react";
import { ArrowRight } from "lucide-react";
import hero1 from "@/assets/hero-1.jpg";
import hero2 from "@/assets/hero-2.jpg";
import hero3 from "@/assets/hero-3.jpg";

const slides = [
  {
    image: hero1,
    eyebrow: "The Lumia Collection",
    headline: "European Kitchen\nLuxury, Reimagined.",
    sub: "Italian design energy meets Swedish engineering precision.\nWelcome to JANSKA.",
    cta: null,
  },
  {
    image: hero2,
    eyebrow: "Precision · Engineered",
    headline: "The Lumia\nCollection",
    sub: "Bold design. Precision performance. Luxury appliances\ncrafted to command attention.",
    cta: "Explore Collection",
  },
  {
    image: hero3,
    eyebrow: "For The Modern Kitchen",
    headline: "Engineered for the\nModern Kitchen",
    sub: "Professional performance with refined European design.",
    cta: "View Products",
  },
];

export const Hero = () => {
  const [active, setActive] = useState(0);

  useEffect(() => {
    const id = setInterval(() => setActive((i) => (i + 1) % slides.length), 7000);
    return () => clearInterval(id);
  }, []);

  return (
    <section className="relative h-[88vh] min-h-[600px] w-full overflow-hidden bg-noir">
      {/* Slides */}
      {slides.map((slide, i) => (
        <div
          key={i}
          className={`absolute inset-0 transition-opacity duration-[1600ms] ease-luxury ${
            active === i ? "opacity-100 z-10" : "opacity-0 z-0"
          }`}
        >
          <img
            src={slide.image}
            alt=""
            className={`w-full h-full object-cover ${active === i ? "animate-ken-burns" : ""}`}
            loading={i === 0 ? "eager" : "lazy"}
          />
          <div className="absolute inset-0 bg-gradient-to-t from-noir via-noir/40 to-noir/30" />
          <div className="absolute inset-0 bg-gradient-to-r from-noir/70 via-transparent to-transparent" />
        </div>
      ))}

      {/* Content */}
      <div className="relative z-20 h-full mx-auto max-w-[1600px] px-6 lg:px-12 flex items-end pb-24 lg:pb-32">
        <div key={active} className="max-w-2xl animate-fade-up">
          <div className="flex items-center gap-3 mb-6">
            <span className="block w-12 h-px bg-silver-bright" />
            <span className="text-eyebrow text-silver-bright/90">{slides[active].eyebrow}</span>
          </div>
          <h1 className="font-display text-5xl md:text-6xl lg:text-7xl text-silver-bright leading-[1.05] whitespace-pre-line">
            {slides[active].headline}
          </h1>
          <p className="mt-6 text-silver/75 text-base md:text-lg max-w-xl whitespace-pre-line leading-relaxed font-light">
            {slides[active].sub}
          </p>
          {slides[active].cta && (
            <button className="group mt-10 inline-flex items-center gap-3 px-8 py-4 border border-silver/40 hover:border-silver-bright bg-noir/30 backdrop-blur-sm hover:bg-silver-bright text-silver-bright hover:text-noir transition-all duration-700 ease-luxury">
              <span className="font-mono-mech text-[0.7rem]">{slides[active].cta}</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-500" strokeWidth={1.25} />
            </button>
          )}
        </div>
      </div>

      {/* Slide indicators */}
      <div className="absolute z-20 bottom-8 right-6 lg:right-12 flex items-center gap-6">
        <span className="font-mono-mech text-[0.65rem] text-silver/60 tabular-nums">
          {String(active + 1).padStart(2, "0")} / {String(slides.length).padStart(2, "0")}
        </span>
        <div className="flex gap-2">
          {slides.map((_, i) => (
            <button
              key={i}
              onClick={() => setActive(i)}
              className="relative h-px w-10 bg-silver/20 overflow-hidden"
              aria-label={`Slide ${i + 1}`}
            >
              <span
                className={`absolute inset-y-0 left-0 bg-silver-bright transition-all ease-linear ${
                  active === i ? "w-full duration-[7000ms]" : "w-0 duration-300"
                }`}
              />
            </button>
          ))}
        </div>
      </div>
    </section>
  );
};
