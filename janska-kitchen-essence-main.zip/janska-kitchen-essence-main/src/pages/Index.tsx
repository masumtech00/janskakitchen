import { Header } from "@/components/janska/Header";
import { Hero } from "@/components/janska/Hero";
import { BrandStatement } from "@/components/janska/BrandStatement";
import { Collections } from "@/components/janska/Collections";
import { Categories } from "@/components/janska/Categories";
import { Trade } from "@/components/janska/Trade";
import { Vezeni } from "@/components/janska/Vezeni";
import { Footer } from "@/components/janska/Footer";
import { useEffect } from "react";

const Index = () => {
  useEffect(() => {
    document.title = "JANSKA — European Kitchen Luxury, Reimagined";
    const meta = document.querySelector('meta[name="description"]');
    const content =
      "JANSKA luxury kitchen appliances. Italian design energy meets Swedish engineering precision. Designed in Stockholm. Built to be seen. Built to last.";
    if (meta) meta.setAttribute("content", content);
    else {
      const m = document.createElement("meta");
      m.name = "description";
      m.content = content;
      document.head.appendChild(m);
    }
  }, []);

  return (
    <div className="min-h-screen bg-noir text-silver-bright">
      <Header />
      <main>
        <Hero />
        <BrandStatement />
        <Collections />
        <Categories />
        <Trade />
        <Vezeni />
      </main>
      <Footer />
    </div>
  );
};

export default Index;
