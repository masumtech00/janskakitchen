import { useState } from "react";
import { Search, User, MapPin, Menu, X } from "lucide-react";

const navItems = ["Products", "About", "Owners", "Professionals"];

export const Header = () => {
  const [dealerOpen, setDealerOpen] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <header className="fixed top-0 inset-x-0 z-50 bg-noir/80 backdrop-blur-xl border-b border-hairline">
      <div className="mx-auto max-w-[1600px] px-6 lg:px-12 h-16 flex items-center justify-between">
        {/* Logo */}
        <a href="#" className="font-display text-2xl tracking-[0.4em] text-silver-bright select-none">
          JANSKA
        </a>

        {/* Nav */}
        <nav className="hidden lg:flex items-center gap-10">
          {navItems.map((item) => (
            <a
              key={item}
              href={`#${item.toLowerCase()}`}
              className="font-mono-mech text-[0.7rem] text-silver/80 hover:text-silver-bright transition-colors duration-500 relative group"
            >
              {item}
              <span className="absolute -bottom-1 left-0 right-0 h-px bg-silver-bright origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-700 ease-luxury" />
            </a>
          ))}
        </nav>

        {/* Right */}
        <div className="flex items-center gap-1">
          {/* Find a Dealer pin */}
          <div
            className="hidden md:flex items-center"
            onMouseEnter={() => setDealerOpen(true)}
            onMouseLeave={() => setDealerOpen(false)}
          >
            <button className="flex items-center gap-2 px-3 py-2 text-silver/80 hover:text-silver-bright transition-colors group">
              <MapPin className="w-4 h-4" strokeWidth={1.25} />
              <span
                className={`font-mono-mech text-[0.65rem] overflow-hidden transition-all duration-700 ease-luxury whitespace-nowrap ${
                  dealerOpen ? "max-w-[140px] opacity-100 ml-0" : "max-w-0 opacity-0"
                }`}
              >
                Find a Dealer
              </span>
            </button>
          </div>
          <button className="p-2 text-silver/80 hover:text-silver-bright transition-colors">
            <User className="w-4 h-4" strokeWidth={1.25} />
          </button>
          <button className="p-2 text-silver/80 hover:text-silver-bright transition-colors">
            <Search className="w-4 h-4" strokeWidth={1.25} />
          </button>
          <button
            className="lg:hidden p-2 text-silver/80 hover:text-silver-bright transition-colors"
            onClick={() => setMobileOpen(!mobileOpen)}
            aria-label="Menu"
          >
            {mobileOpen ? <X className="w-4 h-4" strokeWidth={1.25} /> : <Menu className="w-4 h-4" strokeWidth={1.25} />}
          </button>
        </div>
      </div>

      {/* Mobile menu */}
      {mobileOpen && (
        <div className="lg:hidden border-t border-hairline bg-noir animate-fade-in-slow">
          <nav className="flex flex-col px-6 py-6 gap-5">
            {navItems.map((item) => (
              <a key={item} href={`#${item.toLowerCase()}`} className="font-mono-mech text-xs text-silver/80">
                {item}
              </a>
            ))}
            <a className="font-mono-mech text-xs text-silver/80 flex items-center gap-2">
              <MapPin className="w-3.5 h-3.5" strokeWidth={1.25} /> Find a Dealer
            </a>
          </nav>
        </div>
      )}
    </header>
  );
};
