export const Vezeni = () => {
  return (
    <section className="relative bg-charcoal py-28 lg:py-36 border-y border-hairline overflow-hidden">
      <div className="mx-auto max-w-4xl px-6 lg:px-12 text-center">
        <div className="text-eyebrow text-silver/50 mb-8">Manufacturing Partnership</div>
        <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-silver-bright leading-tight">
          Powered by <span className="text-metal italic">Vezeni</span>
        </h2>
        <p className="mt-10 text-silver/65 text-lg leading-relaxed max-w-2xl mx-auto font-light">
          JANSKA is proudly developed in partnership with Vezeni, combining advanced manufacturing expertise
          with modern European design to create a new generation of luxury kitchen appliances.
        </p>
        <div className="mt-12 flex items-center justify-center gap-4">
          <span className="block w-16 h-px bg-silver/30" />
          <span className="font-mono-mech text-[0.65rem] text-silver/40">Stockholm · Engineered Without Shortcuts</span>
          <span className="block w-16 h-px bg-silver/30" />
        </div>
      </div>
    </section>
  );
};
