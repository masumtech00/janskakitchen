import { Flame, Wind, Snowflake, Droplets, ChefHat, Soup } from "lucide-react";

const categories = [
  {
    icon: Flame,
    name: "Professional Ranges",
    items: ["30\" Gas Range", "36\" Gas Range", "48\" Gas Range", "30/36/48\" Dual Fuel"],
  },
  {
    icon: ChefHat,
    name: "Rangetops",
    items: ["30\" Induction", "36\" Induction", "48\" Induction"],
  },
  {
    icon: Soup,
    name: "Wall Ovens",
    items: ["30\" Double Wall Oven"],
  },
  {
    icon: Wind,
    name: "Ventilation",
    items: ["30\" Rangehood", "36\" Rangehood", "48\" Rangehood"],
  },
  {
    icon: Snowflake,
    name: "Refrigeration",
    items: ["30\" French Door", "36\" French Door"],
  },
  {
    icon: Droplets,
    name: "Dishwashing",
    items: ["24\" Built-In"],
  },
];

export const Categories = () => {
  return (
    <section className="relative bg-noir py-32 lg:py-40 border-t border-hairline">
      <div className="mx-auto max-w-[1600px] px-6 lg:px-12">
        <div className="flex items-end justify-between mb-16 lg:mb-20 flex-wrap gap-8">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="block w-12 h-px bg-silver-bright/60" />
              <span className="text-eyebrow">Product Categories</span>
            </div>
            <h2 className="font-display text-4xl md:text-5xl text-silver-bright leading-tight max-w-2xl">
              The complete kitchen, <span className="italic text-silver/60">composed.</span>
            </h2>
          </div>
          <a href="#" className="font-mono-mech text-[0.7rem] text-silver/70 hover:text-silver-bright transition-colors border-b border-silver/30 hover:border-silver-bright pb-1">
            View All Products
          </a>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-hairline border border-hairline">
          {categories.map(({ icon: Icon, name, items }) => (
            <a
              key={name}
              href="#"
              className="group bg-noir p-10 lg:p-12 hover:bg-charcoal transition-colors duration-700 ease-luxury relative"
            >
              <Icon className="w-8 h-8 text-silver-bright mb-8 transition-transform duration-700 ease-luxury group-hover:scale-110" strokeWidth={1} />
              <h3 className="font-display text-2xl lg:text-3xl text-silver-bright mb-6">{name}</h3>
              <ul className="space-y-2">
                {items.map((it) => (
                  <li key={it} className="text-silver/55 text-sm font-light hover:text-silver-bright transition-colors">
                    {it}
                  </li>
                ))}
              </ul>
              <span className="absolute bottom-0 left-0 right-0 h-px bg-silver-bright origin-left scale-x-0 group-hover:scale-x-100 transition-transform duration-1000 ease-luxury" />
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};
