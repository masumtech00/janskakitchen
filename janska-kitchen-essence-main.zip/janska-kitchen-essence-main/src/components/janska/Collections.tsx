import { ArrowUpRight } from "lucide-react";
import lumia from "@/assets/collection-lumia.jpg";
import heritage from "@/assets/collection-heritage.jpg";

const collections = [
  {
    n: "01",
    name: "Lumia Collection",
    tag: "Black PVD · Precision Controls",
    image: lumia,
    desc: "The pinnacle of JANSKA design philosophy. Bold surfaces, precision controls, and refined mechanical performance designed for modern luxury kitchens.",
  },
  {
    n: "02",
    name: "Heritage Collection",
    tag: "Brushed Steel · Timeless Form",
    image: heritage,
    desc: "Timeless craftsmanship and professional-grade performance for serious kitchens. Classic design with modern engineering.",
  },
];

export const Collections = () => {
  return (
    <section id="products" className="relative bg-charcoal py-32 lg:py-40">
      <div className="mx-auto max-w-[1600px] px-6 lg:px-12">
        <div className="flex items-end justify-between mb-16 lg:mb-24">
          <div>
            <div className="flex items-center gap-3 mb-6">
              <span className="block w-12 h-px bg-silver-bright/60" />
              <span className="text-eyebrow">Collections</span>
            </div>
            <h2 className="font-display text-4xl md:text-6xl text-silver-bright leading-tight max-w-2xl">
              Two philosophies.
              <br />
              <span className="italic text-silver/60">One standard.</span>
            </h2>
          </div>
        </div>

        <div className="grid lg:grid-cols-2 gap-px bg-hairline border border-hairline">
          {collections.map((c) => (
            <a
              key={c.n}
              href="#"
              className="group relative bg-noir overflow-hidden block"
            >
              <div className="relative aspect-[4/5] overflow-hidden bg-noir">
                <img
                  src={c.image}
                  alt={c.name}
                  loading="lazy"
                  className="w-full h-full object-cover transition-transform duration-[2000ms] ease-luxury group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-noir via-noir/30 to-transparent" />
                <div className="absolute inset-0 bg-noir/20 group-hover:bg-noir/0 transition-colors duration-700" />
              </div>

              <div className="absolute inset-0 p-8 lg:p-12 flex flex-col justify-end">
                <div className="font-mono-mech text-[0.65rem] text-silver/50 mb-4">
                  {c.n} · {c.tag}
                </div>
                <h3 className="font-display text-3xl lg:text-5xl text-silver-bright mb-4">
                  {c.name}
                </h3>
                <p className="text-silver/70 max-w-md leading-relaxed mb-6 font-light">{c.desc}</p>
                <div className="inline-flex items-center gap-2 text-silver-bright">
                  <span className="font-mono-mech text-[0.7rem]">Discover</span>
                  <ArrowUpRight
                    className="w-4 h-4 transition-transform duration-700 ease-luxury group-hover:translate-x-1 group-hover:-translate-y-1"
                    strokeWidth={1.25}
                  />
                </div>
              </div>
            </a>
          ))}
        </div>
      </div>
    </section>
  );
};
