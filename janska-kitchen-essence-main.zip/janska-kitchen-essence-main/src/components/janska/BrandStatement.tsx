export const BrandStatement = () => {
  return (
    <section id="about" className="relative bg-noir py-32 lg:py-48 overflow-hidden">
      <div className="mx-auto max-w-5xl px-6 lg:px-12">
        <div className="flex items-center gap-3 mb-10">
          <span className="block w-12 h-px bg-silver-bright/60" />
          <span className="text-eyebrow">Manifesto · 01</span>
        </div>
        <h2 className="font-display text-3xl md:text-5xl lg:text-6xl text-silver-bright leading-[1.15] tracking-tight">
          JANSKA combines the expressive boldness of{" "}
          <span className="italic text-silver/70">Italian design</span> with the precision and discipline of{" "}
          <span className="italic text-silver/70">Swedish engineering</span>.
        </h2>
        <p className="mt-12 text-silver/60 text-lg lg:text-xl max-w-3xl leading-relaxed font-light">
          The result is a new generation of luxury kitchen appliances designed not only to perform flawlessly,
          but to elevate the visual identity of the modern kitchen.
        </p>

        <div className="mt-20 grid md:grid-cols-3 gap-px bg-hairline border border-hairline">
          {[
            { n: "01", t: "Every detail is intentional." },
            { n: "02", t: "Every component is engineered for longevity." },
            { n: "03", t: "Every appliance is built to become the centerpiece." },
          ].map((item) => (
            <div key={item.n} className="bg-noir p-10 lg:p-12">
              <div className="font-mono-mech text-[0.65rem] text-silver/40 mb-6">{item.n}</div>
              <p className="font-display text-xl lg:text-2xl text-silver-bright leading-snug">{item.t}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};
