import { Instagram, Youtube, Linkedin } from "lucide-react";

const cols = [
  { title: "Discover", links: ["Products", "Lumia Collection", "Heritage Collection", "About"] },
  { title: "Support", links: ["Owners", "Manuals & Guides", "Service & Care", "Login"] },
  { title: "Network", links: ["Professionals", "Trade Resources", "Find a Dealer", "Search"] },
];

export const Footer = () => {
  return (
    <footer className="relative bg-noir border-t border-hairline">
      <div className="mx-auto max-w-[1600px] px-6 lg:px-12 py-20 lg:py-24">
        <div className="grid lg:grid-cols-12 gap-12">
          <div className="lg:col-span-5">
            <div className="font-display text-3xl tracking-[0.4em] text-silver-bright mb-6">JANSKA</div>
            <p className="font-display text-2xl text-silver/70 leading-snug max-w-md italic">
              Designed in Stockholm.<br />
              Engineered without shortcuts.<br />
              Built to be seen. Built to last.
            </p>
          </div>

          {cols.map((col) => (
            <div key={col.title} className="lg:col-span-2">
              <div className="font-mono-mech text-[0.65rem] text-silver/40 mb-5">{col.title}</div>
              <ul className="space-y-3">
                {col.links.map((l) => (
                  <li key={l}>
                    <a href="#" className="text-silver/70 hover:text-silver-bright text-sm font-light transition-colors duration-500">
                      {l}
                    </a>
                  </li>
                ))}
              </ul>
            </div>
          ))}

          <div className="lg:col-span-1 flex lg:flex-col gap-4 lg:items-end">
            {[Instagram, Youtube, Linkedin].map((Icon, i) => (
              <a key={i} href="#" className="text-silver/50 hover:text-silver-bright transition-colors">
                <Icon className="w-4 h-4" strokeWidth={1.25} />
              </a>
            ))}
          </div>
        </div>

        <div className="mt-16 pt-8 border-t border-hairline flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="font-mono-mech text-[0.6rem] text-silver/40">
            © {new Date().getFullYear()} JANSKA · A Vezeni Brand · All Rights Reserved
          </div>
          <div className="flex gap-6">
            {["Privacy", "Terms", "Cookies", "Accessibility"].map((l) => (
              <a key={l} href="#" className="font-mono-mech text-[0.6rem] text-silver/40 hover:text-silver-bright transition-colors">{l}</a>
            ))}
          </div>
        </div>
      </div>
    </footer>
  );
};
