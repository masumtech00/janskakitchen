import { ArrowRight } from "lucide-react";
import hero3 from "@/assets/hero-3.jpg";

export const Trade = () => {
  return (
    <section id="professionals" className="relative bg-noir overflow-hidden">
      <div className="grid lg:grid-cols-2 min-h-[560px]">
        <div className="relative overflow-hidden order-2 lg:order-1">
          <img
            src={hero3}
            alt="Built for professionals"
            loading="lazy"
            className="absolute inset-0 w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-r from-noir via-noir/40 to-transparent" />
        </div>

        <div className="relative bg-charcoal p-10 md:p-16 lg:p-24 flex items-center order-1 lg:order-2">
          <div>
            <div className="flex items-center gap-3 mb-8">
              <span className="block w-12 h-px bg-silver-bright/60" />
              <span className="text-eyebrow">For Trade · Architects · Designers</span>
            </div>
            <h2 className="font-display text-4xl md:text-5xl lg:text-6xl text-silver-bright leading-[1.1]">
              Built for <span className="italic text-silver/60">Professionals.</span>
            </h2>
            <p className="mt-8 text-silver/65 text-lg leading-relaxed max-w-lg font-light">
              JANSKA works closely with kitchen designers, builders, architects, and appliance specialists
              to deliver exceptional kitchen experiences. Access product specifications, installation guides,
              and trade resources.
            </p>
            <button className="group mt-12 inline-flex items-center gap-3 px-8 py-4 border border-silver/40 hover:bg-silver-bright hover:text-noir text-silver-bright transition-all duration-700 ease-luxury">
              <span className="font-mono-mech text-[0.7rem]">Trade Resources</span>
              <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform duration-500" strokeWidth={1.25} />
            </button>
          </div>
        </div>
      </div>
    </section>
  );
};
